// merge sort (in place)
// print out the intermediary steps
// (printed after merging step)
	let arr = [];
// array to be sorted
$(function() {
	updateArr();
});


// new number inputbox html element: #numEnter
// new number submit button html element: #numSubmit
// jquery onclick for the submit button
$('#numSubmit').on('click', function() {
	event.preventDefault();

	let num = $('#numEnter').val();

	if (num) {
		arr.push(parseFloat(num));
		updateArr();
		$('#numEnter').val('');
	}
});


$('#resetButton').on('click', function() {
	event.preventDefault();

	resetArr();
});

	// have a button that starts the sort
	// if length = 0, print an error
	// if length = 1, return original array (or just do nothing)
	// if length > 1, do mergesort
$('#startSort').on('click', function() {
		event.preventDefault();

		startSort();
});

// function to update the dom based on arr
	function updateArr() {
		// currently domElement is #arrayHolder
		let domElement = '#arrayHolder';

		if (arr.length === 0) {
			$(domElement).html('Array is empty');
		} else {
			let htmlOut = '';
			for (let i = 0; i < arr.length - 1; i++ ) {
				htmlOut += arr[i] + ', ';
			}

			htmlOut += arr[arr.length-1];

			$(domElement).html(htmlOut);
		}

	} // end of updateArr()

	function addArr(arr) {
		// currently domElement is #intermediateHolder
		let domElement = '#intermediateHolder';


			let htmlOut = '<li>';
			for (let i = 0; i < arr.length - 1; i++ ) {
				htmlOut += arr[i] + ', ';
			}

			htmlOut += arr[arr.length-1] + '</li> <br>';

			$(domElement).append(htmlOut);

	} // end of addArr()

	function resetArr() {
		// currently domElement is #intermediateyHolder
		let domElement = '#intermediateHolder';
		// empty list of intermediate arrays from sort
			$(domElement).html('');

			// reset arr
			arr = [];
			updateArr();

	} // end of resetArr()

	function startSort() {
		addArr(arr);
		arr = mergesort(arr);
		updateArr();
	} // end of startArr()

// =================================================
// === merge sort using indices as arguments ===
// =================================================

// array = arr, starting index = m, ending index = n;
// m cannot be greater than n
// median index = Math.floor((n+m)/2)
// return true if all swaps completed
function mergesort(arr) {

		if (arr.length <= 1) {
			addArr(arr);
			return arr;
		}

		// instea of sorting in places with indices we use new arrays because easier to keep track of returns
		// make copies of the subarrays and use them to fill in (to avoid complicated swaps)

		// mergesort the subdivisions
		let n = arr.length-1;

		let arr1 = mergesort(arr.slice(0, Math.floor(n/2)+1));
		let arr2 = mergesort(arr.slice(Math.floor(n/2)+1));
		console.log('arr1');
		console.log(arr1);
		console.log('arr2');
		console.log(arr2);

		let result = [];

		// merging two subarrays in order by comparing the first two indices
		while (arr1.length > 0 || arr2.length > 0) {
			if (arr1.length > 0) {
				if (arr2.length > 0) {
					if (arr1[0] < arr2[0]) {
						result.push(arr1[0]);
						arr1.shift();


					} else {
						result.push(arr2[0]);
						arr2.shift();

					}
				} else {
					result.push(arr1[0]);
					arr1.shift();

				}
			} else {
				result.push(arr2[0]);
				arr2.shift();

			}
			// console.log('result');
			// console.log(result);
			// console.log('arr1');
			// console.log(arr1);
			// console.log('arr2');
			// console.log(arr2);
		} // end while loop

	addArr(result);
	return result;
}
